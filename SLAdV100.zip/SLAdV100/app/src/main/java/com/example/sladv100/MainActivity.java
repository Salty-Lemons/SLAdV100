package com.example.sladv100;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_earn:
                    mTextMessage.setText("Earn");
                    return true;
                case R.id.navigation_rewards:
                    mTextMessage.setText("Rewards");
                    return true;
                case R.id.navigation_acct:
                    mTextMessage.setText("Account");
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNav = findViewById(R.id.navigation);
        bottomNav.setOnNavigationItemReselectedListener (navListener);
    }

    private  BottomNavigationView.OnNavigationItemReselectedListener navListener =
            new BottomNavigationView.OnNavigationItemReselectedListener() {
                @Override
                public void onNavigationItemReselected(@NonNull MenuItem menuItem) {
                    Fragment selectedFragment = null;

                    switch (menuItem.getItemId()) {
                        case R.id.navigation_home:
                            selectedFragment = new Home();
                            break;
                        case R.id.navigation_earn:
                            selectedFragment = new EarnFragment();
                            break;
                        case R.id.navigation_rewards:
                            selectedFragment = new RewardsFragment();
                            break;
                        case R.id.navigation_acct:
                            selectedFragment = new AcctFragment();
                            break;
                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.container,selectedFragment).commit();
                }
            };

}
